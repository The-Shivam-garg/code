# Roadmap

- [x] Add and verify a delayed, dismissible sample testimonial popup with a configurable destination.

- [x] Rebuild the opening museum wall with live inscription, illustrated television installation and clickable impact screens; verify layout and records.

- [x] Recreate the central illustration with a beside-art paragraph and ornamental name matching the reference; verify the composition.

- [x] Add subtle heritage carvings and the reference television-stack character; verify artwork and portrait popups.

- [x] Increase museum portrait spacing and keep open records over the visible blurred wall; verify all walls at multiple sizes.

- [x] Unify all museum portrait records and balance the second and third scattered walls; verify every portrait.

- [x] Add three opening frames and stagger the remaining museum layouts; verify framing and card interactions.

- [x] Append the twelve-portrait museum wall after Products with six stops and interactive story cards.
- [x] Verify gallery navigation, accessibility, small-screen layout and operation without artwork downloads.

- [x] Move the About journey line clear below the statue and drop the Agra label from the cover strip.
- [x] Verify About cover spacing, the trimmed strip and translations across screen sizes.

- [x] Fix About opening/navbar overlap across screen sizes without changing Home navigation.
- [x] Add two translated scroll-reading paragraphs before the chess, life and finance section and verify their placement.

- [x] Harden Products layouts and touch controls across narrow, tablet and wide screens.
- [x] Defer Products artwork and verify interactions with slow or unavailable image downloads.

- [x] Apply Rapido’s eight-segment format to every product with synchronized product-specific content and previews.
- [x] Verify every product chapter and preview controls across screen sizes.

- [x] Match the latest Products image with corrected proportions, artwork placement and tablet composition.
- [x] Verify Products visual fidelity and interactions across screen sizes.

- [x] Restore the Products reference background and verify it loads visibly.
- [x] Fix and verify Products text, artwork and controls across screen sizes.

- [x] Build the complete interactive Chapter 5 products section after the community journey.
- [x] Verify product chapters, previews, project controls and small-screen layout.

- [x] Offer activity choices across all seven life pillars.
- [ ] Suggest authentic About-page modifications after the user selects their real experiences (awaiting answers).

- [x] Reduce image and unnecessary initial downloads without changing the portfolio design.
- [x] Verify both pages and key interactions under a throttled connection.

- [x] Check and fix clipped headings, text, images and controls across both pages and screen sizes.
- [x] Add and verify a dismissible first-arrival language hint beside the header selector.

- [x] Match the port-39 introduction and full-width unboxed metrics band.
- [x] Verify left-to-right metrics movement, click actions and responsive layout.

- [x] Add an eight-language selector to the header.
- [x] Translate both pages and dynamic content, remembering the visitor's choice.
- [x] Verify language switching, persistence, navigation, and narrow-screen layout.

- [x] Align navbar with the editorial theme and preserve contrast.
- [x] Preserve the desktop introduction composition on smaller screens.
- [x] Add GTM hover/focus hints and a zoom-dependent reset control.
- [x] Expand company metric toggles to at least two rows and verify all updates.

- [x] Replace cropped book imagery with live cover/pages and synchronize all writing with the selected reading topic.
- [x] Separate and animate the individual characters before the footer.
- [x] Verify reading topics, book controls and character interactions across screen sizes.

- [x] Add and verify the moneyincheck.org word-by-word scroll-darkening effect on About.

- [x] Add the About tab and complete interactive port-37 page.
- [x] Verify About navigation, reading controls, artwork and small-screen layout.

- [x] Recreate the four-panel uploaded reference with working controls.
- [x] Match the reference website's mouse movement.
- [x] Verify interactions and layout.
- [x] Add the complete port-27 work-history section after expertise.
- [x] Verify company selection, photo details, highlights, and small-screen layout.
- [x] Repeat the complete HeLa detail template for every company.
- [x] Add richer highlight details and a moving 12-metric strip with click glow.
- [x] Verify company switching, highlight details, metric glow, and responsive motion.
- [x] Add the complete GTM map and organization directory from port-28.
- [x] Add hover-gradient map regions and interactive directory controls.
- [x] Verify map hover, filtering, card details, and responsive layout.
- [x] Add the complete interactive journey directory from port-29.
- [x] Add live category filters, row details, and ecosystem impact controls.
- [x] Verify directory filtering, details, ecosystem selection, and small-screen layout.
- [x] Add complete community profiles with core responsibilities and outcomes.
- [x] Make every journey row open the expanded community profile.
- [x] Verify profile interactions and responsive layout.
- [x] Replace GTM with the new world map and regional highlight reference.
- [x] Add glowing interactive map squares, region filters, scrolling and regional details.
- [x] Verify regional counts, interactions and layout.
- [x] Match the updated work-history reference with heading, responsibilities, gallery, highlights and technologies.
- [x] Verify work interactions, new impact counts and small-screen layout.
- [x] Add the complete port-34 introduction as the first section with live navigation, text, buttons and statistics.
- [x] Verify introduction controls, artwork and small-screen layout.
- [x] Recreate the updated GTM dashboard with country-aware clickable squares and regional cards.
- [x] Apply requested illustrative country and Indian state colors and verify details, filters and layout.
- [x] Restore the complete map silhouette and add zoom, pan and region/country/state/city navigation.
- [x] Verify full-map framing, location zoom, wheel gestures and narrow-screen controls.
- [x] Keep expertise in a two-by-two grid at every width and verify movement and controls on narrow screens.
