import { createFileRoute } from '@tanstack/react-router';
import { ExpertiseGrid } from '@/components/expertise-grid';
import { WorkHistory } from '@/components/work-history';
import { GtmShowcase } from '@/components/gtm-showcase';
import { JourneySection } from '@/components/journey-section';
import { SiteNav } from '@/components/site-nav';
import { Introduction } from '@/components/introduction';
import { ProductShowcase } from '@/components/product-showcase';
import { MuseumWall } from '@/components/museum-wall';
import { TestimonialNudge } from '@/components/testimonial-nudge';
import background from '@/assets/intro/background-port39.webp.asset.json';

export const Route = createFileRoute('/')({
  head: () => ({
    links: [{ rel: 'preload', as: 'image', href: background.url, fetchpriority: 'high' }],
    meta: [
        { title: 'Shivam · DoraDAO — Communities, Products & Impact' },
      {
        name: 'description',
          content: 'Meet Shivam, building DoraDAO and connecting Web3, open-source and developer communities. Explore his work, expertise, global network and impact.',
      },
        { property: 'og:title', content: 'Shivam · DoraDAO — Communities, Products & Impact' },
      {
        property: 'og:description',
         content: 'Explore expertise, work history, a global GTM network, and a filtered journey through communities, products and ecosystems.',
      },
      { property: 'og:type', content: 'website' },
      { name: 'twitter:card', content: 'summary_large_image' },
    ],
  }),
  component: Index,
});

function Index() {
   return <><SiteNav page="home" /><Introduction /><ExpertiseGrid /><WorkHistory /><GtmShowcase /><JourneySection /><ProductShowcase /><MuseumWall /><TestimonialNudge /></>;
}
