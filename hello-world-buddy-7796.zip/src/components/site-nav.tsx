import { useLanguage } from '@/components/language-provider';
import { useEffect, useState } from 'react';
import { Link } from '@tanstack/react-router';
import { ArrowLeft, ArrowRight, Menu, X, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { LanguageSelector } from '@/components/language-selector';

const homeLinks = [
  { label: 'Expertise', target: '.expertise-page' },
  { label: 'Work', target: '.work-section' },
  { label: 'GTM Map', target: '.gtm-section' },
  { label: 'Journey', target: '.journey-section' },
];
const aboutLinks = [
  { label: 'The Book', target: '#about-book' },
  { label: 'Rules', target: '.about-rules' },
];

const smooth = () => (window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth') as ScrollBehavior;
const goTo = (selector: string) => document.querySelector(selector)?.scrollIntoView({ behavior: smooth(), block: 'start' });

export function SiteNav({ page }: { page: 'home' | 'about' }) {
  const { t } = useLanguage();
  const links = page === 'home' ? homeLinks : aboutLinks;
  const [active, setActive] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [contact, setContact] = useState(false);
  const [copied, setCopied] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0;
      setScrolled(window.scrollY > 40);
      const line = window.innerHeight * 0.35;
      let current: string | null = null;
      for (const link of links) {
        const el = document.querySelector(link.target);
        if (el && el.getBoundingClientRect().top <= line) current = link.target;
      }
      setActive(current);
    };
    const schedule = () => { if (!frame) frame = requestAnimationFrame(update); };
    update();
    window.addEventListener('scroll', schedule, { passive: true });
    window.addEventListener('resize', schedule);
    return () => { window.removeEventListener('scroll', schedule); window.removeEventListener('resize', schedule); cancelAnimationFrame(frame); };
  }, [links, page]);

  const jump = (target: string) => { setOpen(false); goTo(target); };
  const top = () => { setOpen(false); window.scrollTo({ top: 0, behavior: smooth() }); };

  return <>
    <header className={`site-nav${scrolled ? ' is-scrolled' : ''}${open ? ' is-open' : ''}`}>
      <nav aria-label={t("Site navigation")}>
        <Button variant="ghost" className="site-nav-brand" onClick={top} aria-label={t("Back to top")}>{t("Shivam ")}<span aria-hidden="true">✦</span></Button>
        {page === 'about' && <Button variant="ghost" className="site-nav-link site-nav-about" asChild><Link to="/"><ArrowLeft />{t(" Home")}</Link></Button>}
        <div className="site-nav-links">
          {links.map(link => <Button key={link.target} variant="ghost" className="site-nav-link" data-active={active === link.target} aria-current={active === link.target ? 'true' : undefined} onClick={() => jump(link.target)}>{t(String(link.label))}</Button>)}
        </div>
        {page === 'home' && <Button variant="ghost" className="site-nav-link site-nav-about" asChild><Link to="/about">{t("About ")}<ArrowRight /></Link></Button>}
        <Button className="site-nav-contact" onClick={() => setContact(true)}>{t("Say Hello")}</Button>
        <LanguageSelector welcome={page === 'home'} />
        <Button variant="ghost" size="icon" className="site-nav-toggle" aria-label={t(String(open ? 'Close menu' : 'Open menu'))} aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</Button>
      </nav>
      {open && <div className="site-nav-drawer">{links.map(link => <Button key={link.target} variant="ghost" data-active={active === link.target} onClick={() => jump(link.target)}>{t(String(link.label))}</Button>)}{page === 'home' ? <Button variant="ghost" asChild><Link to="/about">{t("About ")}<ArrowRight /></Link></Button> : <Button variant="ghost" asChild><Link to="/"><ArrowLeft />{t(" Home")}</Link></Button>}</div>}
    </header>
    <Dialog open={contact} onOpenChange={value => { setContact(value); if (!value) setCopied(false); }}>
      <DialogContent className="intro-dialog">
        <DialogTitle>{t("Let’s start a conversation.")}</DialogTitle>
        <DialogDescription>{t("Find the communities, products and people behind DoraDAO.")}</DialogDescription>
        <Button variant="outline" className="intro-copy" onClick={async () => { try { const url = new URL(window.location.href); url.hash = ''; await navigator.clipboard.writeText(url.href); setCopied(true); } catch { setCopied(false); } }}>{copied ? <Check /> : <Copy />}{t(String(copied ? 'Portfolio link copied' : 'Copy portfolio link'))}</Button>
      </DialogContent>
    </Dialog>
  </>;
}
