# Community detail pages

## Goal
Make every community entry open a substantial detail experience instead of the current small popup.

## Changes
- Add distinct community background, summary, core responsibilities, focus areas, and outcomes for all seven journey entries.
- Make the full community row clickable while preserving the image and arrow controls.
- Replace the compact popup with a responsive, page-like detail panel showing the community identity, role, dates, location, overview, responsibilities, focus tags, and related image.
- Keep keyboard navigation, close behavior, mobile layout, and reduced-motion support intact.
- Add data tests confirming every community includes detailed copy and core responsibilities.

## Technical details
- Extend the existing browser-safe journey data model rather than creating new routes, because this is an in-section detail experience.
- Continue using the existing dialog system, styled as a large editorial panel consistent with the journey section.
- Verify opening a community from the row and arrow, closing it, and rendering correctly on desktop and mobile.
