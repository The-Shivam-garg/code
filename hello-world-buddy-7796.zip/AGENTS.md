<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Give pages their own routes and metadata to keep them independent.
- Isolate About artwork, tokens and links; preserve Home and book interactions.
- Keep About navigation in normal flow with scoped positioning; reserve multilingual cover space without changing Home.
- Use a focused scroll-text wrapper for About statements, preserving semantic text and inline artwork with frame-scheduled scroll updates and reduced-motion support; this keeps reading effects independent from page controls.
- Keep About reading in a focused component with one browser-safe topic data source for cover, spread and supporting writing; this guarantees every topic selection stays synchronized.
- Render the pre-footer illustrations as separate transparent assets in a focused character component with individual motion and dialogs; this avoids animating a flattened strip.
- Keep src/styles.css on the default design tokens and add only the styles the current page actually needs; this prevents leftovers from a discarded design from leaking into the next one.
- Keep the four-panel expertise experience in a focused shared component rendered by the index route; this isolates panel state and pointer interactions from routing.
- Use extracted reference artwork through asset pointers, while rebuilding text, controls, navigation and map as live elements; this preserves visual fidelity without flattening the interface.
- Keep expertise tracks two-by-two at all breakpoints, adapting panel interiors instead; animate tracks and the synchronized intersection on pointer or keyboard entry with a reduced-motion fallback so narrow screens retain the structural interaction.
- Keep work-history company data, gallery photos, responsibilities and technologies in a browser-safe data module with a focused shared component; isolate company selection and gallery state from other home sections.
- Keep GTM in a focused shared component with browser-safe regional and precomputed country/state square data; derive geography offline with d3-geo so every live square opens an accurate location without shipping large boundaries.
- Use a focused d3-zoom hook and shared map-location module for GTM navigation; built-in wheel, drag and pinch handling keeps location zoom and manual panning consistent.
- Keep the journey timeline in its own shared component and data module; this keeps category filtering and ecosystem interactions independent from earlier sections.
- Keep community profile content in the journey data module and present it through the journey section's detail panel; this keeps every community entry complete and consistently interactive.
- Keep the introduction in a focused shared component before existing home sections, using extracted artwork and live text and controls; this keeps its navigation and dialog state independent from the expertise experience.
- Keep introduction metrics in equal-width duplicated marquee sets with interaction pause and reduced-motion fallback; this preserves continuous movement without boxing individual metrics or losing keyboard access.
- Keep visitor language in a shared browser-safe provider with lazy-loaded bundled dictionaries and translate at rendering boundaries, never mutate the DOM or business data; this preserves interactive state, SSR hydration and scroll-word effects across pages. Browser storage is only a device preference, not shared application data.
- Keep the first-arrival language hint anchored to the shared selector with device-only dismissal; this keeps it aligned without prompting visitors who have already chosen a language.
- Measure introduction text columns with ResizeObserver to reserve space above the moving metrics; this preserves the three-column composition without clipping longer translations.
- Serve optimized artwork and self-hosted WOFF2 fonts through immutable asset pointers, use media-selected sources for mobile-only artwork and lazy-load below-fold images; this reduces bandwidth without gating text or controls on image completion.
- Keep locale downloads lazy and retry failed loads on renewed connectivity or explicit reselection; this prevents interrupted language downloads from breaking navigation or becoming permanently stuck.
- Keep the products showcase in a focused shared component with scoped CSS and browser-safe case-study data; this isolates chapters, ride previews and project selection from the community directory.
- Load the Products photographic backdrop as a lazy, low-priority decorative image over a solid fallback; artwork downloads must never gate case-study controls or text.
- Render all product case studies through one eight-chapter template with browser-safe per-product data; this prevents layout and interaction drift between products.
- Keep museum placements and opening focused, with separate artwork and live TV controls; share records and pin the wall during modal scroll lock to prevent drift.
- Use validated company events and stable anchors for museum links; Work History retains state ownership.

- Isolate testimonial dwell prompts with configurable sample data; never invent endorsements.
