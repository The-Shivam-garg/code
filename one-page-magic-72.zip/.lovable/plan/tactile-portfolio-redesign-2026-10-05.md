# Tactile portfolio redesign

## Goal
Rebuild The Trail with the same tactile, illustrated stage language as the reference site, while retaining Shivam Garg’s existing sections, copy, metrics, links, and interactions.

## Visual direction
- Replace the light full-page editorial canvas with a dark, authoritative exhibition stage.
- Present each major stop as a large warm-paper artifact with red-clay and credibility-green accents, layered sheets, graph-paper details, hand-drawn marks, tape, stamps, and edge ornaments.
- Keep Fraunces, Inter, and Caveat, but use them with stronger hierarchy and tighter restraint.
- Adapt the reference composition rather than copying its personal illustrations: The Trail gets original route, field-note, compass, passport, hill, and community motifs.

## First impression
- Build a framed opening artifact containing Shivam’s name, positioning, four proof metrics, and direct Work / Get in touch actions.
- Keep every achievement visible immediately; no intro gate or delayed reveal.
- Let the Kitchen Table scene visibly emerge as the lower folded page, matching the reference’s continuous physical composition.

## Whole-page system
- Preserve all nine existing stops in their current order and keep their content unchanged.
- Restyle section containers, overlays, polaroids, signposts, the menu, passport, guide, and trail progress as one cohesive tactile system.
- Turn the green trail into an edge rail / stitched route motif that remains usable as progress and navigation.
- Retain current interactive verbs, keyboard access, reduced-motion behavior, mobile layout, and download/contact paths.

## Technical details
- Centralize the new authority palette, textures, borders, and shadows in the global design tokens.
- Add reusable decorative primitives rather than duplicating styling in every stop.
- Use CSS/SVG illustration only; no copied artwork or external hotlinked assets.
- Verify the full opening and representative lower sections at desktop and mobile sizes, then check the current build diagnostics.
