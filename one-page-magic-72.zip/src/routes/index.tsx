import { useCallback, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { JourneyProvider } from "@/components/trail/journey";
import { MenuOverlay, OpeningBeat, Sky, TopBar } from "@/components/trail/chrome";
import { Gate } from "@/components/trail/stops-a";
import { Village } from "@/components/trail/stops-c";
import { NightCamp } from "@/components/trail/stops-d";
import { BaseCampEnd, Postcards } from "@/components/trail/stops-e";
import { ChalkDoodles } from "@/components/trail/ChalkDoodles";
import { HoomanSection } from "@/components/trail/HoomanSection";
import { HoomanBoard } from "@/components/trail/HoomanBoard";
import { VoicePrompt } from "@/components/trail/VoicePrompt";
import { stops } from "@/data/trail";

const title = "Shivam Garg — The Trail: a timeline of belief";
const description = "Walk the trail of Shivam Garg, community builder, DevRel and ecosystem lead across Web3, open source and developer communities in India.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title }, { name: "description", content: description },
      { property: "og:title", content: title }, { property: "og:description", content: description },
       { property: "og:type", content: "profile" }, { name: "twitter:card", content: "summary_large_image" },
    ],
    scripts: [{ type: "application/ld+json", children: JSON.stringify({ "@context": "https://schema.org", "@type": "Person", name: "Shivam Garg", jobTitle: "Community builder, DevRel and ecosystem lead", address: { "@type": "PostalAddress", addressCountry: "IN" }, sameAs: ["https://www.linkedin.com/in/meshivamgarg", "https://x.com/Shivams_twt"] }) }],
  }),
  component: () => <JourneyProvider><Trail /></JourneyProvider>,
});

function Trail() {
  const [menu, setMenu] = useState(false);
  const [opening, setOpening] = useState(true);
  const finishOpening = useCallback(() => setOpening(false), []);
  return (
    <>
      <OpeningBeat onComplete={finishOpening} />
      <div inert={opening} aria-hidden={opening ? true : undefined}>
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-2 focus:top-16 focus:z-[100] focus:bg-paper focus:p-3">Skip to content</a>
      <Sky />
      <TopBar onMenu={() => setMenu(true)} />
      <MenuOverlay open={menu} onClose={() => setMenu(false)} />
      <nav className="sr-only" aria-label="All stops">{stops.map((s) => <a key={s.id} href={`#${s.id}`}>{s.name}</a>)}</nav>
      <main id="main" className="trail-stage relative">
        <ChalkDoodles />
        <Gate /><Village /><NightCamp /><Postcards /><HoomanSection /><HoomanBoard /><BaseCampEnd />
      </main>
      <VoicePrompt enabled={!opening && !menu} />
      </div>
    </>
  );
}
